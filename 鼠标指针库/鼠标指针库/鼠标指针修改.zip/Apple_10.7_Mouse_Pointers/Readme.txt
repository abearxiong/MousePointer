� 2OO9 Apple Inc.

Select all "Right click and Install (...)" files, right-click and select "Install".
Then go to Mouse control panel & enjoy one of themes.

Suits perfectly Windows 7.