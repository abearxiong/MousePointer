Gant Mario

Created by Behelit ( Adamantiou Thomas ) 
daoc.hib@gmail.com
http://behelit.deviantart.com

Original Mario Cursor made by Ryan Clark
http://www.ryanclarkdesign.com

For any use of the cursor mail at ryan@ryanclarkdesign.com

!!!!!!!!!IMPORTANT FOR INSTALL !!!!!!!!!!
Just right click on the "Install.inf" file and click on "Install". 
Then in the control panel apply and to the mouse section and choose Mario Gant.


Enjoy !